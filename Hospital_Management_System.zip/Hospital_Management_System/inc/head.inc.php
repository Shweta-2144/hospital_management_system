<link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="css/q.css" />
<link rel="stylesheet" type="text/css" href="css/animate.css" />
<link rel="stylesheet" type="text/css" href="css/main.css" />

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/q.js"></script>
<script src="js/system.js"></script>
<script src='js/jQuery.print.js' ></script>