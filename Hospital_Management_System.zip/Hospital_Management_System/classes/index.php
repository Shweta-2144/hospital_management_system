<?php
// silence is gold